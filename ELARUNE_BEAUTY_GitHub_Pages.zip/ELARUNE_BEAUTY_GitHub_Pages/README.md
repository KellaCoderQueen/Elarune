# ELARUNE BEAUTY — Telegram Mini App

GitHub Pages-ready static storefront for the ELARUNE BEAUTY Telegram Mini App.

Publish the contents of this folder from the `main` branch using GitHub Pages.
